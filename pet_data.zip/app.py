from flask import Flask, request, jsonify
import json

app = Flask(__name__)

# Load knowledge base
with open("pet_data.json", "r") as file:
    data = json.load(file)

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()
    response = data.get(user_message, "I'm sorry, I don't have an answer for that.")
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
